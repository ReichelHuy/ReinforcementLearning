import matplotlib.pyplot as plt
import numpy as np
# Số lượng bước đi
step_counts = {
    'UCS': [],
    'DFS': [],
    'BFS': []
}

# Thời gian chạy
runtimes = {
    'UCS': [],
    'DFS': [],
    'BFS': []
}

# Đọc dữ liệu từ các file trong các folder
folders = ['UCS', 'DFS', 'BFS']
levels = range(1, 19)

for level in levels:
    for folder in folders:
        file_path = f'/Users/duynguyendinh/Downloads/coderun/python/DeepLearning/Report/{folder}/sokobanSolver/Solverlevel_{level}.txt'
        with open(file_path, 'r') as file:
            lines = file.readlines()
            steps_line = lines[0].strip()
            time_line = lines[1].strip().split(': ')[1]
            
            # Đếm số lượng bước đi
            step_counts[folder].append(steps_line.count(','))
            
            # Lưu thời gian chạy
            runtimes[folder].append(float(time_line))

# Biểu đồ số lượng bước đi
x = np.arange(1, 19)

plt.plot(x, step_counts['UCS'], label='UCS')
plt.plot(x, step_counts['DFS'], label='DFS')
plt.plot(x, step_counts['BFS'], label='BFS')

plt.xlabel('Level')
plt.ylabel('Step Count')
plt.title('Step Counts Comparison')
plt.legend()
plt.xticks(x)
plt.yticks(np.arange(0, max(step_counts['DFS'])+50, 50))
plt.grid(True, linestyle='--', linewidth=0.5)
for i, j in zip(x, step_counts['UCS']):
    plt.text(i, j, str(j), ha='center', va='bottom')
plt.show()

# Biểu đồ thời gian chạy
plt.plot(x, runtimes['UCS'], label='UCS')
plt.plot(x, runtimes['DFS'], label='DFS')
plt.plot(x, runtimes['BFS'], label='BFS')

plt.xlabel('Level')
plt.ylabel('Runtime')
plt.title('Runtime Comparison')
plt.legend()
plt.xticks(x)
plt.grid(True, linestyle='--', linewidth=0.5)

plt.show()

# Biểu đồ số bước chạy theo màn chơi và thuật toán
bar_width = 0.25
index = np.arange(len(x))

plt.bar(index, step_counts['UCS'], bar_width, label='UCS')
plt.bar(index + bar_width, step_counts['DFS'], bar_width, label='DFS')
plt.bar(index + 2 * bar_width, step_counts['BFS'], bar_width, label='BFS')

plt.xlabel('Level')
plt.ylabel('Step Count')
plt.title('Step Counts by Level and Algorithm')
plt.legend()
plt.xticks(index + bar_width, x)
plt.yticks(np.arange(0, max(step_counts['DFS'])+50, 50))
plt.grid(True, linestyle='--', linewidth=0.5)
plt.grid(True, linestyle='--', linewidth=0.5)
plt.show()
# Tạo bảng
data = np.array(list(step_counts.values()))
rows, cols = data.shape

plt.figure(figsize=(10, 6))
plt.axis('off')

# Tạo tiêu đề hàng đầu tiên
header_row = [''] + [f'Level {i}' for i in range(1, cols + 1)]
cell_text = [header_row]

# Tạo dữ liệu cho các hàng còn lại
for i, (key, values) in enumerate(step_counts.items()):
    row = [key] + values
    cell_text.append(row)

# Vẽ bảng
table = plt.table(cellText=cell_text, loc='center', cellLoc='center', colWidths=[0.063] * (cols + 1))

# Thiết lập định dạng cho bảng
table.auto_set_font_size(False)
table.set_fontsize(9)
table.scale(1, 1.5)

plt.title('Step Counts by Level and Algorithm')

# Tạo không gian trống bên dưới bảng để hiển thị đầy đủ 18 màn chơi
plt.subplots_adjust(bottom=0.2)

plt.show()