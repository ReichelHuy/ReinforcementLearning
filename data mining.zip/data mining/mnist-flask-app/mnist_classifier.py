import mlp
import numpy as np
import os
import glob
import pickle
# Import image converter
from fig_to_mnist import mnist_treat
# ------------


def classify(fig):

    # Standard MNIST format is 28x28 pixels and grayscale.
    height, width, depth = 28, 28, 1

    # Proccess image (c.f. fig_to_misc.py) and convert to numpy array
    X = mnist_treat(fig)
    X_array = np.array(X)

    # Flatten image
    X_flat = X_array.reshape(1, height * width)

    # Normalize to 1 = white.
    X_flat = X_flat.astype('float32')
    X_flat /= 255

    net = mlp.MLP()

    # load latest model
    path = os.path.join(os.curdir, 'models/*')
    files = sorted(
        glob.iglob(path), key=os.path.getctime, reverse=True)

    net.load(files[0])
    # Run prediction
    prediction = net.predict(X_flat)

    return prediction[0]

def classify_ver2(fig):
    # Standard MNIST format is 28x28 pixels and grayscale.
    height, width, depth = 28, 28, 1

    # Proccess image (c.f. fig_to_misc.py) and convert to numpy array
    X = mnist_treat(fig)
    X_array = np.array(X)

    # Flatten image
    X_flat = X_array.reshape(1,height * width)

    # Normalize to 1 = white.
    X_flat = X_flat.astype('float32')
    X_flat /= 255

    X_pred = X_array.reshape(height * width)
    X_pred = X_pred.astype('float32')
    X_pred /= 255
    
    # load latest model
    path = os.path.join(os.curdir, 'models/*')
    files = sorted(
        glob.iglob(path), key=os.path.getctime, reverse=True)
    with open(files[0],'rb') as f:
        model = pickle.load(f)
    f.close()
    # Run prediction
    prediction = model.predict(X_pred)
    return prediction

