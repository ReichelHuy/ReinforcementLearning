# MNIST Flask demo 
# Requirement
  * Python 3.>
  * Flask
  * OpenCV
  * Numpy
  * Transformer
## Running
python application.py
## Training
python train.py

