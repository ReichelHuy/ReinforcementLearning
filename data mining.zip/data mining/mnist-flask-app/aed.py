from docx import Document
from faker import Faker

def generate_text(word_count):
    """Tạo một đoạn văn bản ngẫu nhiên với số lượng từ được chỉ định."""
    fake = Faker()
    text = ' '.join(fake.paragraph() for _ in range(word_count // 100))  # Mỗi đoạn khoảng 100 từ
    return text

def create_word_file(filename, text):
    """Tạo file Word với nội dung được chỉ định."""
    doc = Document()
    doc.add_heading('Tiêu đề của Tài liệu', level=1)
    doc.add_paragraph(text)
    doc.save(filename)

if __name__ == "__main__":
    # Số từ mong muốn
    word_count = 2000
    filename = 'output.docx'
    
    # Tạo nội dung và file
    text = generate_text(word_count)
    create_word_file(filename, text)
    print(f"File '{filename}' đã được tạo với {word_count} từ.")